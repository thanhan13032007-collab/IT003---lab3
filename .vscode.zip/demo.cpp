#include <iostream>
#include <vector>
#include <string>
#include <utility>
using namespace std;

void swap(string &a, string &b)
{
    string c = a;
    a = b;
    b = c;
}

bool sosanhbehon(const string &a, const string &b)
{
    if (a.size() != b.size())
        return a.size() < b.size();
    return a < b;
}

bool sosanhlonhon(const string &a, const string &b)
{
    if (a.size() != b.size())
        return a.size() > b.size();
    return a > b;
}

// Sap xep ma hang tang dan theo gia tri so
void sapxep(vector<string> &ds, int left, int right)
{
    int i = left, j = right;
    string pivot = ds[left + (right - left) / 2];

    while (i <= j)
    {
        while (sosanhbehon(ds[i], pivot))
            i++;

        while (sosanhlonhon(ds[j], pivot))
            j--;

        if (i <= j)
        {
            swap(ds[i], ds[j]);
            i++;
            j--;
        }
    }

    if (left < j)
        sapxep(ds, left, j);

    if (i < right)
        sapxep(ds, i, right);
}

// Dem so lan xuat hien cua tung ma
void dem(vector<pair<string, int>> &ds_dem,const vector<string> &ds)
{
    int n = ds.size();
    if (n == 0) return;

    string temp = ds[0];
    int count = 1;

    for (int i = 1; i < n; i++)
    {
        if (ds[i] == temp)
        {
            count++;
        }
        else
        {
            ds_dem.push_back({temp, count});
            temp = ds[i];
            count = 1;
        }
    }

    ds_dem.push_back({temp, count});
}

// a dung truoc b theo yeu cau de bai
bool behon(const pair<string, int> &a,
           const pair<string, int> &b)
{
    if (a.second != b.second)
        return a.second > b.second;

    return sosanhbehon(a.first, b.first);
}

bool lonhon(const pair<string, int> &a,
            const pair<string, int> &b)
{
    if (a.second != b.second)
        return a.second < b.second;

    return sosanhlonhon(a.first, b.first);
}

void swap_dsdem(pair<string, int> &a,pair<string, int> &b)
{
    pair<string, int> c = a;
    a = b;
    b = c;
}

// Sap xep theo so luong giam dan, ma hang tang dan
void sapxep_ds_dem(vector<pair<string, int>> &ds_dem,int left, int right)
{
    int i = left, j = right;
    pair<string, int> pivot =
        ds_dem[left + (right - left) / 2];

    while (i <= j)
    {
        while (behon(ds_dem[i], pivot))
            i++;

        while (lonhon(ds_dem[j], pivot))
            j--;

        if (i <= j)
        {
            swap_dsdem(ds_dem[i], ds_dem[j]);
            i++;
            j--;
        }
    }

    if (left < j)
        sapxep_ds_dem(ds_dem, left, j);

    if (i < right)
        sapxep_ds_dem(ds_dem, i, right);
}

int main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(nullptr);

    int n;
    cin >> n;

    vector<string> ds(n);

    for (int i = 0; i < n; i++)
        cin >> ds[i];

    if (n > 1)
        sapxep(ds, 0, n - 1);

    vector<pair<string, int>> ds_dem;
    ds_dem.reserve(n);

    dem(ds_dem, ds);

    if (ds_dem.size() > 1)
        sapxep_ds_dem(ds_dem, 0, (int)ds_dem.size() - 1);

    for (const auto &p : ds_dem)
        cout << p.first << " " << p.second << '\n';

    return 0;
}
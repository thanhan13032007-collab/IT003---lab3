#include <iostream>
#include <vector>
#include <string>
#include <utility>
using namespace std;
void swap(string &a,string&b)
{
    string c = a;
    a = b;
    b = c;
}
bool sosanhbehon(string &a,string &b)
{
    if(a.size() != b.size())
        return a.size() < b.size();
    return a < b;
}
bool sosanhlonhon(string &a,string &b)
{
    if(a.size() != b.size())
        return a.size() > b.size();
    return a > b;
}

void sapxep(vector<string> &ds,int left,int right)
{
    string pivot = ds[(left+right)/2];
    int i = left;
    int j = right;
    while(i<=j)
    {
        while((ds[i]<pivot))
            i++;
        while((ds[j]>pivot))
            j--;
    
        if(i<=j)
        {
            swap(ds[i],ds[j]);
            i++;
            j--;
        }
    }
 
    if(left < j)
        sapxep(ds,left,j);
    if(right > i)
        sapxep(ds,i,right);
}
void dem(vector<pair<string,int>> & ds_dem,vector<string> & ds,int n)
{
    string temp = ds[0];
    int count = 0;
    for(int i = 0;i<n;i++)
    {
        
        if(ds[i] ==temp)
            count++;
        else
        {
            pair<string,int> p;
            p.first = temp;
            p.second = count;
            ds_dem.push_back(p);
            count = 1;
            temp = ds[i];
        }
    }
    pair<string,int> p;
    p.first = temp;
    p.second = count;
    ds_dem.push_back(p);
    
}
bool behon(pair<string,int> &a,pair<string,int> &b)
{
    if(a.second != b.second)
        return a.second > b.second;
    else
        return sosanhbehon(a.first,b.first);
}
bool lonhon(pair<string,int> &a,pair<string,int> &b)
{
    if(a.second != b.second)
        return a.second < b.second;
    else
        return sosanhlonhon(a.first,b.first);
}
void swap_dsdem(pair<string,int> &a,pair<string,int> &b)
{
    pair<string,int> c = a;
    a = b;
    b = c;
}
void sapxep_ds_dem(vector<pair<string,int>> &ds_dem,int left,int right)
{
    pair<string,int> pivot = ds_dem[(left+right)/2];
    int i = left;
    int j = right;
    while(i<=j)
    {
        while(behon(ds_dem[i],pivot))
            i++;
        while(lonhon(ds_dem[j],pivot))
            j--;
    
        if(i<=j)
        {
            swap_dsdem(ds_dem[i],ds_dem[j]);
            i++;
            j--;
        }
    }
 
    if(left < j)
        sapxep_ds_dem(ds_dem,left,j);
    if(right > i)
        sapxep_ds_dem(ds_dem,i,right);
}



int main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(nullptr); 



    int n;
    cin>>n;

    vector<string> ds(n);
    for(int i = 0;i<n;i++)
        cin>> ds[i];

    sapxep(ds,0,n-1);

    vector<pair<string,int>> ds_dem;
    dem(ds_dem,ds,n);

    sapxep_ds_dem(ds_dem,0,ds_dem.size()-1);

    for(int i = 0;i<ds_dem.size();i++)
    {
        cout<< ds_dem[i].first << " "<<ds_dem[i].second <<endl;
    }
}
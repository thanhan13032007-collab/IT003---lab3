#include <iostream>
#include <vector>
#include <string>
using namespace std;
void swap(string &a,string&b)
{
    string c = a;
    a = b;
    b = c;
}

void sapxep(vector<string> &ds,int left,int right)
{
    string pivot = ds[(left+right)/2];
    int i = left;
    int j = right;
    while(i<=j)
    {
        while(ds[i] < pivot)
            i++;
        while(ds[j] >  pivot)
            j--;
    
        if(i<=j)
        {
            swap(ds[i],ds[j]);
            i++;
            j--;
        }
    }
 
    if(left < j)
        sapxep(ds,left,j);
    if(right > i)
        sapxep(ds,i,right);
}




int main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(nullptr); 
    int n;
    cin>>n;
    vector<string> ds(n);
    for(int i = 0;i<n;i++)
        cin>> ds[i];
    sapxep(ds,0,n-1);
    string temp = ds[0];
    int count = 1;
    for(int i = 0;i<n;i++)
    {
        if(ds[i] != temp )
        {
            count++;
            temp = ds[i];
        }
    }
    cout<< count;

}